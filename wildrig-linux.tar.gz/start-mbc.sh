#!/bin/bash

while true
do
./wildrig-multi --algo rainforest --opencl-threads auto --opencl-launch auto --url stratum+tcp://thepool.life:3376 --user BWPgHunXsG2CjC37Xt8c8Ggxiz3g6ZYCv3 --pass c=MBC,d=100
sleep 5
done
